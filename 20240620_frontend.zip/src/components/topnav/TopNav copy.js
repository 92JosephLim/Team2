import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import newLogo from "../../assets/new_logo.png"; // 새로운 로고 이미지 경로
import "../topnav/TopNav.css"; // 스타일 파일 추가
import { MdOutlineLanguage } from "react-icons/md";
import i18next from "../../locales/i18n";
import { useTranslation } from "react-i18next";
import Badge from '@mui/material/Badge';
import Avatar from '@mui/material/Avatar';
import LoginModal from "../modal/LoginModal";

function TopNav() {
  const navigate = useNavigate();
  const { t } = useTranslation();

  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);

  const openLoginModal = () => setIsLoginModalOpen(true);
  const closeLoginModal = () => setIsLoginModalOpen(false);

  // 로그인 상태 확인
  const token = localStorage.getItem('token');
  const email = localStorage.getItem('email');
  const nickName = localStorage.getItem('nickName');
  const profileImage = localStorage.getItem('profileImage');

  const handleLogoClick = () => navigate('/');
  const handleMyPage = () => navigate("/mypage");
  const handleRoomSettings = () => navigate("/settings/RoomSetting");
  const handleVideoAudioSettings = () => navigate("/settings/VideoAudioSetting");
  const handleChatSettings = () => navigate("/settings/ChatSetting");
  const handleOtherSettings = () => navigate("/settings/OtherSetting");

  const clickHandler = (lang) => i18next.changeLanguage(lang);
  const handleLogout = () => {
    localStorage.clear();
    navigate('/');
  };

  return (
    <header className="top">
      {/* 로고 */}
      <div className="logo">
        <button className="logo-button" onClick={handleLogoClick}>
          <img src={newLogo} alt="New Logo" />
        </button>
      </div>
      {/* //로고 끝 */}

      {/* 네브 아이템즈 */}
      <nav className="nav">
        <Link to="/roomList" className="action-link">{t("list")}</Link>
        <div className="dropdown">
          <button className="dropdown-button">{t("About")}</button>
          <div className="dropdown-content">
            <Link to="/announcement">{t("notice")}</Link>
            <Link to="/customerService">{t("customerCenter")}</Link>
          </div>
        </div>
        <div className="dropdown">
          <button className="dropdown-button"><MdOutlineLanguage /></button>
          <div className="dropdown-content">
            <button onClick={() => clickHandler("ko")}>KOREAN</button>
            <button onClick={() => clickHandler("en")}>ENGLISH</button>
            <button onClick={() => clickHandler("zh")}>CHINESE</button>
            <button onClick={() => clickHandler("ja")}>JAPANESE</button>
          </div>
        </div>
        {token && (
          <div className="dropdown">
            <button className="action-button" onClick={handleMyPage}>{t("mypage")}</button>
            <div className="dropdown-content">
              <Link to="/ProfileSettings">{t("profile")}</Link>
              <Link to="/messageChat">{t("chatLog")}</Link>
              <Link to="/invite">{t("addFriend")}</Link>
              <Link to="/friendMain">{t("FriendList")}</Link>
            </div>
          </div>
        )}
        <div className="dropdown">
          <button className="dropdown-button">Settings</button>
          <div className="dropdown-content">
            <button onClick={handleRoomSettings}>{t("roomSetting")}</button>
            <button onClick={handleVideoAudioSettings}>{t("videoSetting")}</button>
            <button onClick={handleChatSettings}>{t("chatSetting")}</button>
            <button onClick={handleOtherSettings}>{t("etcSetting")}</button>
          </div>
        </div>

        {/* 로그인 했을때 로그아웃으로 변경 / 프로필, 닉네임 추가 */}
        <div className="login-options">
          {token ? (
            <div className="user-info">
              <Badge
                overlap="circular"
                anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
                variant="dot"
                sx={{ '& .MuiBadge-dot': { backgroundColor: '#00FF00' } }}
              >
                <Avatar src={profileImage} alt="profileImage" />
              </Badge>
              <span className="mr-4 ms-3" style={{ color: "white" }}>{nickName} 님</span>
              <button onClick={handleLogout} className="bg-red-500 px-3 py-2 rounded-md hover:bg-red-700">{t("logout")}</button>
            </div>
          ) : (
            <>
              <button onClick={openLoginModal} className="login-btn">{t("login")}</button>
            </>
          )}
        </div>
        {/* //로그인/로그아웃 끝 */}
      </nav>
      {/* //네브 아이템즈 끝 */}
      
      {/* 로그인 모달 창 */}
      <LoginModal isOpen={isLoginModalOpen} onRequestClose={closeLoginModal} />
    </header>
  );
}

export default TopNav;
