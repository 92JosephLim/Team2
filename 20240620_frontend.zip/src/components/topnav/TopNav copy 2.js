// TopNav.js
import React, { useState } from "react";
import newLogo from "../../assets/new_logo.png";
import { Link, useNavigate } from "react-router-dom";
import { MdOutlineLanguage } from "react-icons/md";
import i18next from "../../locales/i18n";
import { useTranslation } from "react-i18next";
import Badge from "@mui/material/Badge";
import Avatar from "@mui/material/Avatar";

function TopNav() {
  const navigate = useNavigate();
  const { t } = useTranslation();

  const token = localStorage.getItem("token");
  const email = localStorage.getItem("email");
  const nickName = localStorage.getItem("nickName");
  const profileImage = localStorage.getItem("profileImage");

  const [dropdowns, setDropdowns] = useState({
    about: false,
    language: false,
    settings: false,
    mypage: false,
  });

  const toggleDropdown = (name) => {
    setDropdowns((prev) => ({
      ...prev,
      [name]: !prev[name],
      ...Object.keys(prev)
        .filter((key) => key !== name)
        .reduce((acc, key) => ({ ...acc, [key]: false }), {}),
    }));
  };

  const handleLogoClick = () => {
    navigate("/");
  };

  const handleVideoChat = () => {
    navigate("/video");
  };

  const handleMyPage = () => {
    toggleDropdown("mypage");
  };

  const clickHandler = (lang) => {
    i18next.changeLanguage(lang);
  };

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("email");
    localStorage.removeItem("phoneNumber");
    localStorage.removeItem("gender");
    localStorage.removeItem("profileImage");
    localStorage.removeItem("loginType");
    localStorage.removeItem("gender");
    localStorage.removeItem("nickName");
    navigate("/");
  };

  const handleRoomSettings = () => {
    navigate("/settings/RoomSetting");
  };

  const handleVideoAudioSettings = () => {
    navigate("/settings/VideoAudioSetting");
  };

  const handleChatSettings = () => {
    navigate("/settings/ChatSetting");
  };

  const handleOtherSettings = () => {
    navigate("/settings/OtherSetting");
  };

  return (
    <header className="flex justify-between items-center bg-gray-900 text-white p-4 relative z-10">
      <div className="logo hidden xs:block">
        <button className="logo-button" onClick={handleLogoClick}>
          <img src={newLogo} alt="New Logo" className="h-6 sm:h-8 md:h-10 lg:h-12 w-auto" />
        </button>
      </div>
      <nav className="flex items-center space-x-1 sm:space-x-2 text-xxs xs:text-xs sm:text-sm md:text-base lg:text-lg">
        <button
          className="bg-none border-none p-1 m-1 text-xxs xs:text-xs sm:text-sm md:text-base lg:text-lg cursor-pointer text-white hover:text-blue-600"
          onClick={handleVideoChat}
        >
          {t("room")}
        </button>
        <Link
          to="/roomList"
          className="bg-none border-none p-1 m-1 text-xxs xs:text-xs sm:text-sm md:text-base lg:text-lg cursor-pointer text-white hover:text-blue-600"
        >
          {t("list")}
        </Link>
        <div className="relative inline-block">
          <button
            className="bg-none border-none p-1 m-1 text-xxs xs:text-xs sm:text-sm md:text-base lg:text-lg cursor-pointer text-white hover:text-blue-600"
            onClick={() => toggleDropdown("about")}
          >
            {t("About")}
          </button>
          {dropdowns.about && (
            <div className="absolute bg-gray-800 min-w-[100px] p-0 border border-gray-300 z-20">
              <Link to="/announcement" className="block px-2 py-1 text-white hover:bg-gray-700 text-xxs xs:text-xs sm:text-sm md:text-base lg:text-lg">
                {t("notice")}
              </Link>
              <Link to="/customerService" className="block px-2 py-1 text-white hover:bg-gray-700 text-xxs xs:text-xs sm:text-sm md:text-base lg:text-lg">
                {t("customerCenter")}
              </Link>
            </div>
          )}
        </div>
        <div className="relative inline-block">
          <button
            className="bg-none border-none p-1 m-1 text-xxs xs:text-xs sm:text-sm md:text-base lg:text-lg cursor-pointer text-white hover:text-blue-600"
            onClick={() => toggleDropdown("language")}
          >
            <MdOutlineLanguage className="text-xxs xs:text-xs sm:text-sm md:text-base lg:text-lg" />
          </button>
          {dropdowns.language && (
            <div className="absolute bg-gray-800 min-w-[100px] p-0 border border-gray-300 z-20">
              <button className="block px-2 py-1 text-white hover:bg-gray-700 text-xxs xs:text-xs sm:text-sm md:text-base lg:text-lg" onClick={() => clickHandler("ko")}>
                KOREAN
              </button>
              <button className="block px-2 py-1 text-white hover:bg-gray-700 text-xxs xs:text-xs sm:text-sm md:text-base lg:text-lg" onClick={() => clickHandler("en")}>
                ENGLISH
              </button>
              <button className="block px-2 py-1 text-white hover:bg-gray-700 text-xxs xs:text-xs sm:text-sm md:text-base lg:text-lg" onClick={() => clickHandler("zh")}>
                CHINESE
              </button>
              <button className="block px-2 py-1 text-white hover:bg-gray-700 text-xxs xs:text-xs sm:text-sm md:text-base lg:text-lg" onClick={() => clickHandler("ja")}>
                JAPANESE
              </button>
            </div>
          )}
        </div>
        {token && (
          <div className="relative inline-block">
            <button
              className="bg-none border-none p-1 m-1 text-xxs xs:text-xs sm:text-sm md:text-base lg:text-lg cursor-pointer text-white hover:text-blue-600"
              onClick={handleMyPage}
            >
              {t("mypage")}
            </button>
            {dropdowns.mypage && (
              <div className="absolute bg-gray-800 min-w-[100px] p-0 border border-gray-300 z-20">
                <Link to="/ProfileSettings" className="block px-2 py-1 text-white hover:bg-gray-700 text-xxs xs:text-xs sm:text-sm md:text-base lg:text-lg">
                  {t("profile")}
                </Link>
                <Link to="/messageChat" className="block px-2 py-1 text-white hover:bg-gray-700 text-xxs xs:text-xs sm:text-sm md:text-base lg:text-lg">
                  {t("chatLog")}
                </Link>
                <Link to="/invite" className="block px-2 py-1 text-white hover:bg-gray-700 text-xxs xs:text-xs sm:text-sm md:text-base lg:text-lg">
                  {t("addFriend")}
                </Link>
                <Link to="/friendMain" className="block px-2 py-1 text-white hover:bg-gray-700 text-xxs xs:text-xs sm:text-sm md:text-base lg:text-lg">
                  {t("FriendList")}
                </Link>
              </div>
            )}
          </div>
        )}
        <div className="relative inline-block">
          <button
            className="bg-none border-none p-1 m-1 text-xxs xs:text-xs sm:text-sm md:text-base lg:text-lg cursor-pointer text-white hover:text-blue-600"
            onClick={() => toggleDropdown("settings")}
          >
            Settings
          </button>
          {dropdowns.settings && (
            <div className="absolute bg-gray-800 min-w-[100px] p-0 border border-gray-300 z-20">
              <button className="block px-2 py-1 text-white hover:bg-gray-700 text-xxs xs:text-xs sm:text-sm md:text-base lg:text-lg" onClick={handleRoomSettings}>
                {t("roomSetting")}
              </button>
              <button className="block px-2 py-1 text-white hover:bg-gray-700 text-xxs xs:text-xs sm:text-sm md:text-base lg:text-lg" onClick={handleVideoAudioSettings}>
                {t("videoSetting")}
              </button>
              <button className="block px-2 py-1 text-white hover:bg-gray-700 text-xxs xs:text-xs sm:text-sm md:text-base lg:text-lg" onClick={handleChatSettings}>
                {t("chatSetting")}
              </button>
              <button className="block px-2 py-1 text-white hover:bg-gray-700 text-xxs xs:text-xs sm:text-sm md:text-base lg:text-lg" onClick={handleOtherSettings}>
                {t("etcSetting")}
              </button>
            </div>
          )}
        </div>
        <div className="flex items-center space-x-1 xs:space-x-2">
          {token ? (
            <>
              <Badge overlap="circular" anchorOrigin={{ vertical: "bottom", horizontal: "right" }} variant="dot" color="primary">
                <Avatar src={profileImage} alt="profileImage" className="w-6 h-6 sm:w-8 sm:h-8 md:w-10 md:h-10 lg:w-12 lg:h-12" />
              </Badge>
              <span className="mr-2 xs:mr-4 ml-2 xs:ml-3 text-xxs xs:text-xs sm:text-sm md:text-base lg:text-lg">{nickName} 님</span>
              <button
                onClick={handleLogout}
                className="bg-red-500 px-2 py-1 rounded-md hover:bg-red-700 transition-colors duration-300 text-xxs xs:text-xs sm:text-sm md:text-base lg:text-lg"
              >
                {t("logout")}
              </button>
            </>
          ) : (
            <Link to="/login" className="bg-none border-none p-1 m-1 text-xxs xs:text-xs sm:text-sm md:text-base lg:text-lg cursor-pointer text-white hover:text-blue-600">
              {t("login")}
            </Link>
          )}
        </div>
      </nav>
    </header>
  );
}

export default TopNav;
