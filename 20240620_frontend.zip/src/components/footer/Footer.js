import React from "react";
import { IoLogoGithub } from "react-icons/io5";
import { AiOutlineYoutube } from "react-icons/ai";
import newLogo from "../../assets/new_logo.png";

function Footer() {
  return (
    <footer className="flex flex-col lg:flex-row justify-between bg-gray-900 text-white p-4 lg:p-6 relative z-2">
      <div className="footer-left text-left mb-4 lg:mb-0 text-xs sm:text-sm md:text-base lg:text-lg">
        <div>중앙 정보 기술 인재 개발원</div>
        <div>화상 전화를 통한 글로벌 네트워킹</div>
        <div>팀장 | 임요셉 ewjwej77@gmail.com </div>
        <div>
          팀원 | 김민곤 min-gon@naver.com, 김원중 gimpo5975@naver.com, 도현우 alexdo323@naver.com
        </div>
        <div>박지연 qkrwluds7998@gmail.com, 변의성 qusdml123@gmail.com, 한수정 wow012380@gmail.com</div>
      </div>
      <div className="footer-right text-right text-xs sm:text-sm md:text-base lg:text-lg">
        <div className="flex justify-center lg:justify-end">
          <img src={newLogo} alt="New Logo" className="h-8" />
        </div>
        <div className="mt-2">
          <div>GitHub | <a href="https://github.com/92JosephLim/Team2" className="underline">https://github.com/92JosephLim/Team2</a></div>
          <div>PPT | <a href="https://www.canva.com/design/DAGHI_MQRzs/-g4uMsGntAcBVR1l3sO6Zg/edit" className="underline">https://www.canva.com/design/DAGHI_MQRzs/-g4uMsGntAcBVR1l3sO6Zg/edit</a></div>
          <div>YouTube | </div>
        </div>
      </div>
    </footer>
  );
}

export default Footer;
